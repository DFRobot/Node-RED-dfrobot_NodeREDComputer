make
cp packet_forwarder/lora_pkt_fwd  ../packet_forwarder/lora_pkt_fwd/
